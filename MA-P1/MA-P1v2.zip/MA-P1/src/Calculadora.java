public class Calculadora {

    private static final int MAX_SUMANDOS = 2;

    int sumar(String numero) throws CalculadoraException{

        if (numero==null)
            throw new CalculadoraException();

        numero=numero.replaceAll("\\n",",");
        numero=numero.replaceAll("\\s",""); //Delete spaces
        numero=numero.replaceAll(",","\t,\t");

        if(numero.equals(""))
            return 0;

        String[] nums = numero.split("\\t");

        try {
        int suma = Integer.parseInt(nums[0]);
            for (int i = 1; i < nums.length; i+=2) {
                if(nums[i].equals(",")){
                    suma+= Integer.parseInt(nums[i+1]);
                }
            }

            return suma;

        } catch (NumberFormatException | ArrayIndexOutOfBoundsException e ) {
            throw new CalculadoraException();
        }
    }
}
