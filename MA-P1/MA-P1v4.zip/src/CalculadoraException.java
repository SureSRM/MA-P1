/**
 * Created by sergio on 23/02/17.
 */
public class CalculadoraException extends Exception {

    public CalculadoraException(){}
    public CalculadoraException(String msg){
        super(msg);
    }

}
