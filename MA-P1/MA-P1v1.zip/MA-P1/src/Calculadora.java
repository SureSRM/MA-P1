public class Calculadora {

    private static final int MAX_SUMANDOS = 2;

    int sumar(String numero) throws CalculadoraException{

        if (numero==null)
            throw new CalculadoraException();

        numero=numero.replaceAll("\\s",""); //Delete spaces
        numero=numero.replaceAll(",","\t,\t"); //Delete spaces
        if(numero.equals(""))
            return 0;

        String[] nums = numero.split("\\t");

        int suma = 0;
        int sumandos = 0;
        for(String s : nums){
            try {
                if(sumandos< MAX_SUMANDOS && !s.equals(",")) {
                    suma += Integer.parseInt(s);
                    sumandos++;
                } else if(sumandos<2 && s.equals(",")){

                } else {
                    throw new CalculadoraException();
                }
            } catch (NumberFormatException e) {
                throw new CalculadoraException();
            }
        }

        return suma;
    }
}
