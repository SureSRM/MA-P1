/**
 * Created by sergio on 23/02/17.
 */
public class CalculadoraException extends Exception {

}
